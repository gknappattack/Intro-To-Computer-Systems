/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_210()
{
    return 230920280U;
}

unsigned getval_438()
{
    return 2428995912U;
}

unsigned addval_154(unsigned x)
{
    return x + 3284638024U;
}

unsigned getval_349()
{
    return 2455290281U;
}

unsigned getval_118()
{
    return 3284633928U;
}

void setval_421(unsigned *p)
{
    *p = 3281031256U;
}

void setval_170(unsigned *p)
{
    *p = 3281031240U;
}

unsigned getval_223()
{
    return 3284633930U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_296(unsigned x)
{
    return x + 3677930185U;
}

void setval_406(unsigned *p)
{
    *p = 3281047177U;
}

void setval_478(unsigned *p)
{
    *p = 3229928969U;
}

unsigned getval_371()
{
    return 2447411528U;
}

unsigned getval_474()
{
    return 2447411528U;
}

unsigned getval_111()
{
    return 2497743176U;
}

unsigned addval_357(unsigned x)
{
    return x + 3523793293U;
}

unsigned getval_383()
{
    return 2425406093U;
}

unsigned addval_240(unsigned x)
{
    return x + 3374371081U;
}

unsigned addval_103(unsigned x)
{
    return x + 3223372425U;
}

void setval_165(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_405()
{
    return 3685011081U;
}

void setval_326(unsigned *p)
{
    *p = 3767093405U;
}

void setval_173(unsigned *p)
{
    *p = 3677408905U;
}

void setval_316(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_334(unsigned x)
{
    return x + 3674787337U;
}

unsigned getval_310()
{
    return 3674787465U;
}

unsigned getval_333()
{
    return 3224424841U;
}

void setval_306(unsigned *p)
{
    *p = 3375944137U;
}

unsigned addval_257(unsigned x)
{
    return x + 3284322737U;
}

void setval_379(unsigned *p)
{
    *p = 3526939009U;
}

void setval_190(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_444(unsigned x)
{
    return x + 3234120329U;
}

void setval_341(unsigned *p)
{
    *p = 281264777U;
}

unsigned addval_318(unsigned x)
{
    return x + 3263947377U;
}

unsigned getval_225()
{
    return 3376992649U;
}

void setval_347(unsigned *p)
{
    *p = 3674787481U;
}

unsigned addval_219(unsigned x)
{
    return x + 3676884617U;
}

void setval_166(unsigned *p)
{
    *p = 3223376265U;
}

void setval_461(unsigned *p)
{
    *p = 3224421001U;
}

unsigned getval_462()
{
    return 3252717896U;
}

unsigned addval_299(unsigned x)
{
    return x + 3531919753U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
